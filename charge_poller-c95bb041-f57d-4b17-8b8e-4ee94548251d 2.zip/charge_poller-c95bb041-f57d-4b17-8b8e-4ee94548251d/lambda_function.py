import json
import boto3
import urllib.request

VEHICLE_ID = "VEHICLE_ID"
IFTTT_KEY = "MY_IFTT_KEY"
SECRET_NAME = "tesla_tokens"

def lambda_handler(event, context):
    # Get access token from Secrets Manager
    client = boto3.client("secretsmanager")
    secret = client.get_secret_value(SecretId=SECRET_NAME)
    tokens = json.loads(secret["SecretString"])
    access_token = tokens["access_token"]

    # Call Tesla API for vehicle data
    tesla_url = f"https://owner-api.teslamotors.com/api/1/vehicles/{VEHICLE_ID}/vehicle_data"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    req = urllib.request.Request(tesla_url, headers=headers)

    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode())

        data = result["response"]
        charging_state = data.get("charge_state", {}).get("charging_state", "")

        # If charging, call IFTTT webhook
        if charging_state == "Charging":
            ifttt_url = f"https://maker.ifttt.com/trigger/tesla_start_charge/with/key/{IFTTT_KEY}"
            urllib.request.urlopen(ifttt_url)  # No headers or body needed for simple GET
        else:
            ifttt_url = f"https://maker.ifttt.com/trigger/tesla_end_charge/with/key/{IFTTT_KEY}"
            urllib.request.urlopen(ifttt_url)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "charging_state": charging_state
            })
        }

    except urllib.error.HTTPError as e:
        return {
            "statusCode": e.code,
            "body": f"HTTPError: {e.read().decode()}"
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": f"Unhandled error: {str(e)}"
        }
